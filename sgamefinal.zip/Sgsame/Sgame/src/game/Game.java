package game;

import java.awt.FontFormatException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Game {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;

    public static void startGame(User user) throws FontFormatException {
        final JFrame frame = new JFrame("Snake Game");
        frame.setSize(WIDTH, HEIGHT);

        ImageIcon img = new ImageIcon(Game.class.getResource("/images/snake.jpg"));
        frame.setIconImage(img.getImage());

        //passing user
        SnakeGame game = new SnakeGame(WIDTH, HEIGHT, user);
        frame.add(game);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.pack();
        game.startGame();
    }

    public static void lightTheme(User user) throws FontFormatException {
        final JFrame frame = new JFrame("Snake Game");
        frame.setSize(WIDTH, HEIGHT);

        ImageIcon img = new ImageIcon(Game.class.getResource("/images/snake.jpg"));
        frame.setIconImage(img.getImage());
        
        //passing user 
        lightTheme light = new lightTheme(WIDTH, HEIGHT, user);
        frame.add(light);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.pack();
        light.startGame();
    }

    public static void GuestMode() throws FontFormatException {
        final JFrame frame = new JFrame("Snake Game");
        frame.setSize(WIDTH, HEIGHT);

        ImageIcon img = new ImageIcon(Game.class.getResource("/images/snake.jpg"));
        frame.setIconImage(img.getImage());

        GuestMode guest = new GuestMode(WIDTH, HEIGHT);
        frame.add(guest);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.pack();
        guest.startGame();
    }

    public static void main(String[] args) throws FontFormatException {

    }

}
