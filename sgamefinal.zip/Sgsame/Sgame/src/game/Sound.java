
package game;

import java.io.IOException;
import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Sound {
    private static Clip bgMusicClip;

        public static void playSound(String filePath) {
            try {
                URL soundURL = Sound.class.getResource(filePath);
                if (soundURL == null) {
                    throw new IOException("Sound file not found: " + filePath);
                }

                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundURL);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInputStream);
                clip.start();
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }
        }

        public static void playBgMusic(String filePath) {
            try {
                URL soundURL = Sound.class.getResource(filePath);
                if (soundURL == null) {
                    throw new IOException("Sound file not found: " + filePath);
                }

                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundURL);
                bgMusicClip = AudioSystem.getClip();
                bgMusicClip.open(audioInputStream);
                bgMusicClip.loop(Clip.LOOP_CONTINUOUSLY);
                /*since some games may exceed the time limit we have used this 
            just to show that the bg music will continue 
            to play in loop if the the gamplay exceeds the time limit,
            but in our case the bg audio is already 3mins long
            and the gameplay is expected to finish under this much time*/
                bgMusicClip.start();
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                System.out.println("Sound file not found.");
                e.printStackTrace();
            }
        }

        public static void stopBgMusic() {
            if (bgMusicClip != null && bgMusicClip.isRunning()) {
                bgMusicClip.stop();
            }
        }
    

   
}
