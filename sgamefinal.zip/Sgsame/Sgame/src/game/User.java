
package game;


public class User {
     public String email;
    public int highScore;

    public User(String email, String string1, String string2, int highScore) {
        this.email = email;
        this.highScore = highScore;
    }
}
