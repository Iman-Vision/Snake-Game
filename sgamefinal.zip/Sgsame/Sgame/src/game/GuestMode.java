package game;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.font.TextLayout;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class GuestMode extends JPanel implements ActionListener {

    private final int width;
    private final int height;
    private final int cellSize;
    private final int arcSize = 10;
    private boolean gameOver = false;
    private boolean gameStarted = false;
    private boolean gamePaused = false;
    private Random random = new Random();
    private Direction direction = Direction.RIGHT;
    private Direction newDirection = Direction.RIGHT;
    private GamePoint food;
    private GamePoint specialFood;
    private int bonus;
    private int score = 0;
    private int highScore;
    private int userId;
    private static final int FRAME_RATE = 20;
    private final LinkedList<GamePoint> snake = new LinkedList<>();
    private final Timer specialFoodTimer;
    private Timer gameTimer = new Timer(150, this);
    private Timer speedTimer;
    private int speedIncrementTiming = 10000; //time in milliseconds after which the speed increases
    private int speedIncrement = 15; //the delay decreases each increment

    private final ArrayList<GamePoint> obstacles = new ArrayList<>();
    private final int obstacleCount = 10;

    private BufferedImage appleImage;
    private BufferedImage bonusImage;
    private BufferedImage snakeFaceImage;
    private BufferedImage tntImage;

    private Font minecraft;
    private Font scoreFont;

    private JButton backButton;
    private JButton giveupButton;
    private Login loginPage;

    private boolean isMuted = false;

    public GuestMode(final int width, final int height) throws FontFormatException {
        super();
        this.width = width;
        this.height = height;

        this.highScore = highScore;
        this.cellSize = width / (FRAME_RATE * 2);

        setPreferredSize(new Dimension(width, height));
        setBackground(Color.BLACK);
        specialFoodTimer = new Timer(2500, this);
        try {
            appleImage = ImageIO.read(getClass().getResource("/images/apple.png"));
            bonusImage = ImageIO.read(getClass().getResource("/images/bonus.png"));
            snakeFaceImage = ImageIO.read(getClass().getResource("/images/snake.jpg"));
            tntImage = ImageIO.read(getClass().getResource("/images/tnt.jpg"));

            InputStream fontStream = getClass().getResourceAsStream("/fonts/Minecraft.ttf");
            minecraft = Font.createFont(Font.TRUETYPE_FONT, fontStream).deriveFont(30f);
            scoreFont = minecraft.deriveFont(20f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(minecraft);
        } catch (IOException e) {
            System.out.println("Image not found.");
            e.printStackTrace();
        }

        speedTimer = new Timer(speedIncrementTiming, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int currentDelay = gameTimer.getDelay();
                if (currentDelay > 70) { // Set a minimum delay to cap the maximum speed
                    gameTimer.setDelay(currentDelay - speedIncrement);
                }
            }
        });
        backButton = new JButton("Back to Menu");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goToMenu();
                
            }
        });
         giveupButton = new JButton("GIVE UP");
        giveupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.Sound.stopBgMusic();
                game.Sound.playSound("/sounds/collision.wav");
                goToMenu(); // Call the method to navigate to the main menu
            }
        });

    }

    private void goToMenu() {
        game.Sound.playSound("/sounds/food.wav");
        GuestMenuu guestmenu = new GuestMenuu();
        guestmenu.setVisible(true);

        SwingUtilities.getWindowAncestor(this).dispose();
    }

    public void startGame() {
        resetGameData();
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        requestFocusInWindow();
        specialFoodTimer.start();
        gameTimer.start();
        speedTimer.start();
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(final KeyEvent e) {
                handleKeyEvent(e.getKeyCode());
            }
        });
    }

    private void handleKeyEvent(final int keyCode) {
        if (!gameStarted) {
            if (keyCode == KeyEvent.VK_SPACE) {
                gameStarted = true;
                specialFoodTimer.start();
                Sound.playBgMusic("/sounds/BGmusic.wav");
            }
        } else if (!gameOver) {
            if (keyCode == KeyEvent.VK_SPACE) {
                gamePaused = !gamePaused;
                remove(giveupButton);
                repaint();
                if (gamePaused) {
                    gameTimer.stop();
                    specialFoodTimer.stop();

                } else {
                    gameTimer.start();
                    specialFoodTimer.start();

                }
                repaint(); 
            } else if (keyCode == KeyEvent.VK_M) {
                toggleMute();
            } else {
                switch (keyCode) {
                    case KeyEvent.VK_UP -> {
                        if (direction != Direction.DOWN) {
                            newDirection = Direction.UP;
                        }
                    }
                    case KeyEvent.VK_DOWN -> {
                        if (direction != Direction.UP) {
                            newDirection = Direction.DOWN;
                        }
                    }
                    case KeyEvent.VK_RIGHT -> {
                        if (direction != Direction.LEFT) {
                            newDirection = Direction.RIGHT;
                        }
                    }
                    case KeyEvent.VK_LEFT -> {
                        if (direction != Direction.RIGHT) {
                            newDirection = Direction.LEFT;
                        }
                    }
                }
            }
        } else if (keyCode == KeyEvent.VK_SPACE) {
            gameStarted = false;
            gameOver = false;
            speedTimer.restart();
            resetGameData(); 
        }
    }

    private void toggleMute() {
        isMuted = !isMuted;
        if (isMuted) {
            Sound.stopBgMusic();
        } else {
            Sound.playBgMusic("/sounds/BGmusic.wav");
        }
    }

    private void resetGameData() {
        gameTimer.stop(); 
        gameTimer.setDelay(150); 
        gameTimer.start(); 
        speedTimer.restart(); 
        snake.clear();
        snake.add(new GamePoint(width / 2, height / 2));
        generateFood();
        remove(backButton);
        repaint();
        remove(giveupButton);
        repaint();
        generateObstacles();
        score = 0;
    }

    private void generateObstacles() {
        ensureSpecialFoodInitialized();
        obstacles.clear();
        int minDistanceFromSnake = 5; //define the minimum distance from the snake's starting position
        for (int i = 0; i < obstacleCount; i++) {
            GamePoint obstacle;
            do {
                obstacle = new GamePoint(random.nextInt(width / cellSize) * cellSize,
                        random.nextInt(height / cellSize) * cellSize);
            } while (tooCloseSnake(obstacle, minDistanceFromSnake) || snake.contains(obstacle) || food.equals(obstacle) || specialFood.equals(obstacle));
            obstacles.add(obstacle);
        }
    }

    private boolean tooCloseSnake(GamePoint point, int minDistance) {
        for (GamePoint snakePart : snake) {
            if (Math.abs(point.x - snakePart.x) < minDistance * cellSize && Math.abs(point.y - snakePart.y) < minDistance * cellSize) {
                return true;
            }
        }
        return false;
    }

    private void generateSpecialFood() {
        do {
            specialFood = new GamePoint(random.nextInt(width / cellSize) * cellSize,
                    random.nextInt(height / cellSize) * cellSize);
        } while (snake.contains(specialFood)
                || food.equals(specialFood)
                || tooCloseObstacle(specialFood)
                || tooCloseSnake(specialFood, 1));
        repaint();
    }

    private boolean tooCloseObstacle(GamePoint point) {
        for (GamePoint obstacle : obstacles) {
            if (obstacle.equals(point)) {
                return true;
            }
        }
        return false;
    }
    //SNAKE SIZE INCREMENT
//    private void bonusToSnake(int bonus) {
//        if (snake.isEmpty()) return;
//
//        GamePoint tail = snake.get(snake.size() - 1);
//        GamePoint beforeTail = snake.size() > 1 ? snake.get(snake.size() - 2) : tail;
//
//        int deltaX = tail.x - beforeTail.x;
//        int deltaY = tail.y - beforeTail.y;
//
//        for (int i = 0; i < bonus; i++) {
//            GamePoint newSegment = new GamePoint(tail.x + deltaX * (i + 1), tail.y + deltaY * (i + 1));
//            snake.add(newSegment);
//        }
//    }

    private void ensureSpecialFoodInitialized() {
        if (specialFood == null) {
            specialFood = new GamePoint(random.nextInt(width / cellSize) * cellSize,
                    random.nextInt(height / cellSize) * cellSize);
        }
    }

    private void generateFood() {
        ensureSpecialFoodInitialized();
        do {
            food = new GamePoint(random.nextInt(width / cellSize) * cellSize,
                    random.nextInt(height / cellSize) * cellSize);
        } while (snake.contains(food) || specialFood.equals(food) || obstacles.equals(food) || tooCloseObstacle(food));

    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        if (!gameStarted) {
            printMessage(graphics, "PRESS SPACE BAR TO PLAY !\n< PRESS M TO MUTE OR UNMUTE >");
        } else {

            //CHECK DESIGN
            for (int y = 0; y < height; y += cellSize) {
                for (int x = 0; x < width; x += cellSize) {
                    if ((x / cellSize + y / cellSize) % 2 == 0) {
                        graphics.setColor(Color.BLACK);
                    } else {
                        graphics.setColor(new Color(15, 15, 15));
                    }
                    graphics.fillRect(x, y, cellSize, cellSize);
                }
            }
            //OBSTACLES 
            for (GamePoint obstacle : obstacles) {
                if (tntImage != null) {
                    graphics.drawImage(tntImage, obstacle.x, obstacle.y, cellSize, cellSize, this);
                }
            }

            //FOOD

            if (appleImage != null) {
                graphics.drawImage(appleImage, food.x, food.y, cellSize, cellSize, this);
            }

            // SPECIAL FOOD
            ensureSpecialFoodInitialized();
            if (bonusImage != null) {
                graphics.drawImage(bonusImage, specialFood.x, specialFood.y, cellSize, cellSize, this);
            }
           
            //face with rotation
            for (int i = 0; i < snake.size(); i++) {
                GamePoint point = snake.get(i);
                if (i == 0) {
                    // HEAD AND FACE
                    if (snakeFaceImage != null) {
                        Graphics2D g2d = (Graphics2D) graphics.create();
                        g2d.translate(point.x + cellSize / 2, point.y + cellSize / 2);

                        // Rotate the image based on the direction of movement
                        switch (direction) {
                            case UP ->
                                g2d.rotate(Math.toRadians(270));
                            case DOWN ->
                                g2d.rotate(Math.toRadians(90));
                            case LEFT ->
                                g2d.rotate(Math.toRadians(180));
                            // No rotation needed for right direction, 
                            // because default orientation is already set as right
                        }

                        g2d.drawImage(snakeFaceImage, -cellSize / 2, -cellSize / 2, cellSize, cellSize, this);
                        g2d.dispose();
                    }
                } else {
                    //BODY
                    graphics.setColor(new Color(36, 197, 36));
                    graphics.fillRoundRect(point.x, point.y, cellSize, cellSize, arcSize, arcSize);
                }
            }

            //SCORE COUNTER
            graphics.setFont(scoreFont);
            graphics.setColor(Color.WHITE);
            graphics.drawString("Score: " + score, 5, 20);


            if (gameOver || gamePaused) {
                // blur background
                Graphics2D g2d = (Graphics2D) graphics.create();
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.8f)); //80% dull
                g2d.setColor(Color.black);
                g2d.fillRect(0, 0, width, height);
                if (gameOver) {
                    backButton.setBackground(Color.yellow);
                    backButton.setFont(minecraft);
                    backButton.setBounds((width - 300) / 2, height - 100, 300, 50);
                    add(backButton);
                    specialFoodTimer.stop();

                    if (score > highScore) {
                        highScore = score;
                    }
                    printMessage(graphics, "GAME OVER ! \n> YOUR SCORE: " + score + "\n> HIGH SCORE: " + highScore + "\nPRESS SPACE BAR TO RESTART !");
                } else if (gamePaused) {
                    printMessage(graphics, "GAME PAUSED\nPRESS SPACE BAR TO RESUME ;)");
                    giveupButton.setBackground(Color.yellow);
                    giveupButton.setFont(minecraft);
                    giveupButton.setBounds((width - 300) / 2, height - 100, 300, 50);
                    add(giveupButton);
                    specialFoodTimer.stop();
                }

            }

        }
    }

    public void printMessage(Graphics graphics, final String message) {
        graphics.setFont(minecraft);
        graphics.setColor(Color.WHITE);
        int currentHeight = height / 3;
        final var graphics2D = (Graphics2D) graphics;
        final var frc = graphics2D.getFontRenderContext();
        for (final var line : message.split("\n")) {
            final var layout = new TextLayout(line, graphics.getFont(), frc);
            final var bounds = layout.getBounds();
            final var targetWidth = (float) (width - bounds.getWidth()) / 2;
            layout.draw(graphics2D, targetWidth, currentHeight);
            currentHeight += graphics.getFontMetrics().getHeight();
        }
    }

    private void move() {
        direction = newDirection;

        final GamePoint head = snake.getFirst();
        GamePoint newHead = null;
        switch (direction) {
            case UP -> {
                if (head.y - cellSize < 0) {
                    newHead = new GamePoint(head.x, height - cellSize);
                } else {
                    newHead = new GamePoint(head.x, head.y - cellSize);
                }
            }
            case DOWN -> {
                if (head.y + cellSize >= height) {
                    newHead = new GamePoint(head.x, 0);
                } else {
                    newHead = new GamePoint(head.x, head.y + cellSize);// 
                }
            }
            case LEFT -> {

                if (head.x - cellSize < 0) {
                    newHead = new GamePoint(width - cellSize, head.y);
                } else {
                    newHead = new GamePoint(head.x - cellSize, head.y);// 
                }
            }
            case RIGHT -> {

                if (head.x + cellSize >= width) {
                    newHead = new GamePoint(0, head.y);
                } else {
                    newHead = new GamePoint(head.x + cellSize, head.y);
                }
            }
        }
        snake.addFirst(newHead);

        if (newHead.equals(food)) { //collision with food
            Sound.playSound("/sounds/food.wav");
            generateFood();
            score += 1;
        } else if (newHead.equals(specialFood)) {
            Sound.playSound("/sounds/special.wav");
            score += 5;
            generateSpecialFood();

        } else if (isCollision()) { //body collision
            gameOver = true;
            Sound.stopBgMusic();
            Sound.playSound("/sounds/collision.wav");
            snake.removeFirst();
        } else if (isCollisionTNT()) {
            gameOver = true;
            Sound.stopBgMusic();
            Sound.playSound("/sounds/boom.wav");
            snake.removeFirst();
        } else {
            snake.removeLast();
        }
    }

    private boolean isCollision() {
        final GamePoint head = snake.getFirst();
        final var invalidWidth = (head.x < 0) || (head.x >= width);
        final var invalidHeight = (head.y < 0) || (head.y >= height);
        if (invalidWidth || invalidHeight) {
            return true;
        }

        return snake.size() != new HashSet<>(snake).size();
    }

    private boolean isCollisionTNT() {
        final GamePoint head = snake.getFirst();
        if (obstacles.contains(head)) {

            return true;
        }
        return snake.size() != new HashSet<>(snake).size();
    }

    @Override
    public void actionPerformed(final ActionEvent e) {
        if (e.getSource() == specialFoodTimer) {
            generateSpecialFood();
        }

        if (gameStarted && !gameOver && !gamePaused) {
            move();
        }
        repaint();
    }

    private record GamePoint(int x, int y) {

    }

    private enum Direction {
        UP, DOWN, RIGHT, LEFT
    }

}
