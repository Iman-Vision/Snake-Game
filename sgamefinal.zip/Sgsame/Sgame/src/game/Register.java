package game;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Register extends javax.swing.JFrame {

    public Register() {
        initComponents();
        setLocationRelativeTo(null);
        ImageIcon img = new ImageIcon(Game.class.getResource("/images/snake.jpg"));
        this.setIconImage(img.getImage());
        lbl.setText("<html><u>Already Have An Account Login Here</u></html>");
         try {
            // Load the font file from the resources folder
           Font customFont = Font.createFont(Font.TRUETYPE_FONT, new File("Minecraft.ttf"));
            // Set the font size and style
            Font customFont1 = Font.createFont(Font.TRUETYPE_FONT, new File("Minecraft.ttf"));
            // Set the font size and style
           customFont1 = customFont1.deriveFont(Font.BOLD, 36);
           customFont = customFont.deriveFont(Font.BOLD, 18);
            // Apply the custom font to a component
           jLabel1.setFont(customFont1);
           jLabel2.setFont(customFont);
           jLabel3.setFont(customFont);
           jLabel4.setFont(customFont);
           jLabel5.setFont(customFont);
           jButton1.setFont(customFont);
           jButton2.setFont(customFont);
           
       } catch (IOException | FontFormatException e) {
            // Handle the exception if the font file cannot be loaded
         e.printStackTrace();
       }
   }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        passtxt = new javax.swing.JPasswordField();
        cpasstxt = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        emailtxt = new javax.swing.JTextField();
        txtname = new javax.swing.JTextField();
        lbl = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Register");

        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("OCR A Extended", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Register");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(300, 60, 260, 48);

        jLabel2.setFont(new java.awt.Font("OCR A Extended", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Name:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(140, 150, 160, 20);

        jLabel3.setFont(new java.awt.Font("OCR A Extended", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(140, 210, 170, 20);

        jLabel4.setFont(new java.awt.Font("OCR A Extended", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Password:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(140, 270, 200, 20);

        jLabel5.setFont(new java.awt.Font("OCR A Extended", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Confirm Password:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(140, 330, 290, 20);

        passtxt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(passtxt);
        passtxt.setBounds(440, 260, 220, 40);

        cpasstxt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(cpasstxt);
        cpasstxt.setBounds(440, 320, 220, 40);

        jButton1.setBackground(new java.awt.Color(255, 204, 0));
        jButton1.setFont(new java.awt.Font("OCR A Extended", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 51, 51));
        jButton1.setText("Register");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(490, 420, 130, 30);

        jButton2.setBackground(new java.awt.Color(255, 204, 0));
        jButton2.setFont(new java.awt.Font("OCR A Extended", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 51, 51));
        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(190, 420, 130, 27);

        emailtxt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(emailtxt);
        emailtxt.setBounds(440, 200, 220, 40);

        txtname.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });
        jPanel1.add(txtname);
        txtname.setBounds(440, 140, 220, 40);

        lbl.setForeground(new java.awt.Color(255, 255, 255));
        lbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMouseClicked(evt);
            }
        });
        jPanel1.add(lbl);
        lbl.setBounds(300, 470, 310, 60);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/blur.png"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 800, 600);

        jLabel7.setText("jLabel7");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(10, 10, 37, 16);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        game.Sound.playSound("/sounds/food.wav");
        txtname.setText("");
        passtxt.setText("");
        cpasstxt.setText("");
        emailtxt.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        game.Sound.playSound("/sounds/food.wav");
String name = txtname.getText();
String email = emailtxt.getText();
String pass = new String(passtxt.getPassword());
String pass2 = new String(cpasstxt.getPassword());

// Validate that all fields are filled
if (name.isEmpty() || email.isEmpty() || pass.isEmpty() || pass2.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Please fill all fields!");
    return; // Exit the method if any field is empty
}

// Validate password matching
if (!pass.equals(pass2)) {
    JOptionPane.showMessageDialog(this, "Passwords do not match!");
    return; // Exit the method if passwords do not match
}

Connection con = null;
PreparedStatement pstmt = null;
ResultSet rs = null;

try {
    Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    con = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\lenovo user\\Desktop\\mydb5.accdb");

    String checkQuery = "SELECT COUNT(*) FROM DATA WHERE Email = ?";
    PreparedStatement checkStmt = con.prepareStatement(checkQuery);
    checkStmt.setString(1, email);
    rs = checkStmt.executeQuery();
    rs.next();

    if (rs.getInt(1) > 0) {
        JOptionPane.showMessageDialog(this, "Email already taken!");
        return; // Exit the method if the email is already taken
    }

    String insertQuery = "INSERT INTO DATA (Name, Email, Password) VALUES (?, ?, ?)";
    pstmt = con.prepareStatement(insertQuery);
    pstmt.setString(1, name);
    pstmt.setString(2, email);
    pstmt.setString(3, pass);
    pstmt.executeUpdate();

    

    JOptionPane.showMessageDialog(this, "Registration successful!");

    txtname.setText("");
    emailtxt.setText("");
    passtxt.setText("");
    cpasstxt.setText("");

} catch (ClassNotFoundException ex) {
    Logger.getLogger(Register.class.getName()).log(Level.SEVERE, "Ucanaccess driver not found", ex);
} catch (SQLException ex) {
    Logger.getLogger(Register.class.getName()).log(Level.SEVERE, "SQL Exception", ex);
} finally {
    try {
        if (rs != null) {
            rs.close();
        }
        if (pstmt != null) {
            pstmt.close();
        }
        if (con != null) {
            con.close();
        }
    } catch (SQLException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, "SQL Exception on close", ex);
    
     }
         
   }



    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnameActionPerformed

    private void lblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMouseClicked
        // TODO add your handling code here:
        game.Sound.playSound("/sounds/food.wav");
        Login login = new Login();
        login.setVisible(true);
        Register register = new Register();
        this.dispose();
    }//GEN-LAST:event_lblMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField cpasstxt;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbl;
    private javax.swing.JPasswordField passtxt;
    private javax.swing.JTextField txtname;
    // End of variables declaration//GEN-END:variables
}
